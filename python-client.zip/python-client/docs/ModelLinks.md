# ModelLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**manifest** | **str** | The location to get a manifest for this model to be used in the on-prem container. | [optional] 
**copy_to** | **str** | The location to the model copy action. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


