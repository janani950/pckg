# InternalModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**storage_prefix** | **str** |  | [optional] 
**_self** | **str** | The location of this entity. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


