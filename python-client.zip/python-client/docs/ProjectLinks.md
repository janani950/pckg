# ProjectLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**evaluations** | **str** | The location to get a list of all evaluations of this project. | [optional] 
**datasets** | **str** | The location to get a list of all datasets of this project. | [optional] 
**models** | **str** | The location to get a list of all models of this project. | [optional] 
**endpoints** | **str** | The location to get a list of all endpoints of this project. | [optional] 
**transcriptions** | **str** | The location to get a list of all transcriptions of this project. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


